
http_path = "/"

css_dir = "../assets/css"

sass_dir = "sass"

images_dir = "../assets/images"

javascripts_dir = "../assets/js"

line_comments = false

output_style = :expanded
