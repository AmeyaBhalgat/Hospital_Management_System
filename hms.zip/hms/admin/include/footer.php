<footer>
				<div class="footer-inner">
					<div class="pull-left">
						&copy; <span class="current-year"></span><span class="text-bold text-uppercase"> DBMS Mini-Project</span>
					</div>
					
				</div>
			</footer>